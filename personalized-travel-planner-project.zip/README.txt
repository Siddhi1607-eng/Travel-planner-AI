ROAM — PERSONALIZED TRAVEL PLANNER

Start here
1. Open index.html in Chrome, Edge, or Firefox. No installation is needed.
2. Choose “Plan a new trip”, add a destination and dates, and create your itinerary.
3. Your trips are saved in this browser using local storage.

This is a browser-ready interactive prototype built from the project brief. It includes a dashboard, trip builder, trip cards, itinerary view, interest selection, search, favorites, and local persistence. It uses sample itinerary suggestions and does not connect to an AI service, FastAPI, or Supabase yet. The destination photos and fonts load from the internet; the app itself works without setup.

Project-specific documentation PDFs are arranged into the eight phase folders beside this file. A project overview and status notes are in README.md. The full deliverable archive is available as personalized-travel-planner-project.zip in the parent outputs folder.

Project files
- index.html: complete standalone application
- README.txt: these instructions
