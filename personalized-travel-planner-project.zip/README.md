# Roam - Personalized Travel Itinerary Planner

Roam is a travel-planning project shaped around destination, dates, budget, group size, pace and interests. The included browser prototype demonstrates a dashboard, trip builder and day-by-day sample itinerary.

## Current implementation

- `index.html` is a standalone HTML/CSS/JavaScript prototype.
- Trips are stored in browser `localStorage` on the current device and browser profile.
- Itinerary content is sample content generated from a local template. There is no live generative AI, React build, FastAPI service, Supabase database, authentication, live route data, booking, or group collaboration in this version.
- The browser prototype is designed to run without a build step. The project documents describe the current prototype and the proposed full-stack direction.

## Run the prototype

Open `index.html` in a current browser. No installation is required. Choose **Plan a new trip**, enter a destination and valid dates, then create and view the sample itinerary.

## Project documents

The eight phase folders below contain project-specific PDFs. The additional `Privacy, Security & AI Safety.pdf` is included in Requirement Analysis as a supporting document.

1. `1. Brainstorming & Ideation`
2. `2. Requirement Analysis`
3. `3. Project Design Phase`
4. `4. Project Planning Phase`
5. `5. Project Development Phase`
6. `6.Project Testing`
7. `7.Project Documentation`
8. `8.Project Demonstration`

## Important limitation

Recommendations, operating hours, routes and costs are not live-verified. Check current local sources before relying on travel details. The performance report is a proposed test plan; no performance benchmark is claimed.
